Agent CampusFlow - Demo Project
------------------------------
This is a lightweight demo of Agent CampusFlow (concierge agent).
Files:
  - app.py                : Flask application
  - knowledge_base.json   : Sample campus knowledge base
  - templates/index.html  : Minimal chat UI
  - static/*              : CSS, JS, images

Run locally:
  python -m venv venv
  source venv/bin/activate   # (Windows: venv\Scripts\activate)
  pip install Flask
  python app.py
  Open http://127.0.0.1:5000

Notes:
  - This demo uses simple fuzzy matching. For production, replace with embeddings + vector DB.
  - Reminders are not persisted in this demo.
