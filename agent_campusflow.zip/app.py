from flask import Flask, request, jsonify, render_template, send_from_directory
import json, os, re
from difflib import get_close_matches
from datetime import datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder='static', template_folder='templates')

KB_PATH = os.path.join(APP_DIR, "knowledge_base.json")

def load_kb(path=KB_PATH):
    with open(path, "r", encoding="utf-8") as f:
        kb = json.load(f)
    return kb

KB = load_kb()

def norm(text):
    return re.sub(r'\s+', ' ', (text or "").strip().lower())

def retrieve_answer(query, kb=KB, top_n=3):
    qn = norm(query)
    # try intent
    for entry in kb:
        if entry.get("intent") and entry["intent"].lower() in qn:
            return {"answer": entry["answer"], "source": entry["id"], "confidence": 0.95}
    # fuzzy match
    questions = [norm(e.get("question","")) for e in kb]
    matches = get_close_matches(qn, questions, n=top_n, cutoff=0.6)
    if matches:
        matched_text = matches[0]
        for e in kb:
            if norm(e.get("question","")) == matched_text:
                return {"answer": e["answer"], "source": e["id"], "confidence": 0.9}
    # substring / overlap
    results = []
    for e in kb:
        hay = " ".join([e.get("question",""), e.get("answer",""), " ".join(e.get("tags",[]))])
        if qn in norm(hay):
            results.append(e)
        else:
            tokens = qn.split()
            overlap = sum(1 for t in tokens if t and t in norm(hay))
            if overlap >= max(1, len(tokens)//3):
                results.append(e)
    if results:
        return {"answer": results[0]["answer"], "source": results[0]["id"], "confidence": 0.75}
    # suggestions by tags
    suggestions = []
    for e in kb:
        for tag in e.get("tags", []):
            if tag.lower() in qn:
                suggestions.append(e)
                break
    if suggestions:
        return {"answer": suggestions[0]["answer"], "source": suggestions[0]["id"], "confidence": 0.6}
    return {"answer": "Sorry — I couldn't find an exact answer. Try asking about timetables, locations, faculty, or events.", "source": None, "confidence": 0.0}

def parse_reminder(query):
    m = re.search(r'(\d{4}-\d{2}-\d{2})', query)
    if m:
        date_str = m.group(1)
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d").date()
            if "to " in query:
                msg = query.split("to ",1)[1]
            else:
                msg = "Reminder set for " + date_str
            return {"type":"reminder", "date": date_str, "message": msg}
        except ValueError:
            return None
    return None

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/query", methods=["POST"])
def api_query():
    data = request.json or {}
    query = data.get("query", "")
    if not query:
        return jsonify({"error":"empty query"}), 400
    rem = parse_reminder(query)
    if rem:
        # non-persistent demo reminder
        return jsonify({"answer": f"Reminder noted for {rem['date']}: {rem['message']}", "confidence": 0.98, "source": "reminder"})
    resp = retrieve_answer(query)
    return jsonify(resp)

@app.route("/api/kb", methods=["GET"])
def api_kb():
    return jsonify(KB)

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(os.path.join(APP_DIR, 'static'), filename)

if __name__ == "__main__":
    app.run(debug=True, port=5000)
