const frm = document.getElementById("frm");
const queryInput = document.getElementById("query");
const chat = document.getElementById("chat");

function appendMessage(text, cls="user-msg") {
  const d = document.createElement("div");
  d.className = cls;
  d.innerText = text;
  chat.appendChild(d);
  chat.scrollTop = chat.scrollHeight;
}

frm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = queryInput.value.trim();
  if (!q) return;
  appendMessage(q, "user-msg");
  queryInput.value = "";
  appendMessage("...", "bot-msg typing");
  try {
    const res = await fetch("/api/query", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({query: q})
    });
    const data = await res.json();
    const typ = document.querySelector(".typing");
    if (typ) typ.remove();
    if (data.answer) {
      appendMessage(data.answer, "bot-msg");
      if (data.confidence !== undefined) {
        appendMessage(`(Confidence: ${(data.confidence*100).toFixed(0)}%)`, "meta");
      }
    } else if (data.error) {
      appendMessage("Error: " + data.error, "bot-msg");
    } else {
      appendMessage("No response.", "bot-msg");
    }
  } catch (err) {
    const typ = document.querySelector(".typing");
    if (typ) typ.remove();
    appendMessage("Server error. Try again.", "bot-msg");
  }
});
